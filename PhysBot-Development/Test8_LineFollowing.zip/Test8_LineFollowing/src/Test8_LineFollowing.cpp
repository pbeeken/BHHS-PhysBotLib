/******************************************************************************
  LineFollowingTest.ino
  No implementation of PID control.  This is a bang-bang servo

  This code is released under the [MIT License](http://opensource.org/licenses/MIT).
  Please review the LICENSE.md file included with this example. If you have any questions
  or concerns with licensing, please contact techsupport@sparkfun.com.
  Distributed as-is; no warranty is given.
******************************************************************************/

#include <Streaming.h>
#include <PhysBotLib.h>
#include <PhysBotSensorBar.h>

//const uint8_t SX1509_ADDRESS = 0x3E;  // SX1509 I2C address (00)

PhysBotSensorBar mySensorBar(SX1509_ADDRESS);

PhysBotMotors motors; // Instantiate the motor control object. This only needs
// to be done once.


//Define the states that the decision making machines uses:
enum {
  IDLE_STATE,
  READ_LINE,
  GO_FORWARD,
  GO_TURN,
  GO_PIVOT
};

//struct {
  int state = IDLE_STATE;
  int turn = 0;
  long accTurn = 0;
  unsigned long startTurn = 0L;
//};


void setup() {
  Serial.begin(115200);  // start serial for output
  Serial << endl << "Begin Line Following." << endl << endl;

  //Default: the IR will only be turned on during reads.
  mySensorBar.setBarStrobe();
  //Other option: Command to run all the time
  //mySensorBar.clearBarStrobe();

  //Default: dark on light
  mySensorBar.clearInvertBits();
  //Other option: light line on dark
  //mySensorBar.setInvertBits();

  //Don't forget to call .begin() to get the bar ready.  This configures HW.
  if ( mySensorBar.begin() )
    Serial << "sx1509 IC communication OK" << endl;
  else {
    Serial << "sx1509 IC communication FAILED!" << endl;
    while (1);
    }

  Serial << endl;
}

void loop() {
  int nextState = state;
  int pos;
  int decay;
  int oldSpeed;

  switch (state) {

    case IDLE_STATE:
      // decay the turn
      if ( startTurn ) {
        decay = max(1,(millis()-startTurn)/2);  // the factor is variable
        motors.turn(turn/decay);  // effectively the "D" in the PID action
      }
      nextState = READ_LINE;
      break;

    case READ_LINE:
      // Make decisions based on number of lights triggered.
      switch( mySensorBar.getDensity() ) {
        case 0:
            motors.brake();
            break;
        case 1:
        case 2:
        case 3:
            pos = mySensorBar.getPosition();
            // position can be 0, ±31, ±47, ±63, ±79, ±95, ±111, ±127
            // sensor can be   2,  1,   2,   1,   2,   1,   2,    1
            //  ∆                31  16   16   16   16   16    16
            if ( pos == 0 ) {
              nextState = GO_FORWARD;
              startTurn = 0L;
              }
            else if( abs(pos) < 100 ) {
              nextState = GO_TURN;
              turn = -pos;
              startTurn = millis();
              accTurn += turn;
            }
            else {
              nextState = GO_PIVOT;
              turn = -pos/abs(pos);
            }
            break;

        default:
            nextState = IDLE_STATE;
            break;
        }
      break;

    case GO_FORWARD:
      motors.drive(80);
      nextState = READ_LINE;
      break;

    case GO_TURN:
      motors.turn( turn );
      nextState = IDLE_STATE;
      break;

    case GO_PIVOT:
      oldSpeed = motors.getSpeed();
      motors.brake();
      motors.pivot(50 * turn);
      while( abs(mySensorBar.getPosition())>70 ); // wait until we found the line
      motors.drive(oldSpeed);
      nextState = READ_LINE;
      break;

    default:
      motors.brake();       // Stops both motors
      break;
  }

  state = nextState;
  Serial << "{" << millis() << "," << state << "," << turn << "," << startTurn << "," << accTurn << "," << decay << "}" << endl;

}
