/****************************************************************
Declaration for PhysBotLineTracker

This class develops a full control servo for line following.  With
only three sensors it is tricky to get a good control system operational.
The secret, it turns out is to set the spacing of the sensors so they 
match the line width.  We 3D printed different holders to get the spacing to
match a 1" masking tape line.  The result are 5 control points and an 
ALLSTOP control point.

17 Aug 2015- P. Beeken, Byram Hils High School

Tested and developed in Arduino 1.6.5 on a SparkFun RedBot ROB-13166
all of our machines also come with wheel encoders.  They are not 
supplied with whiskers or xBees. We are too cheap.
****************************************************************/
#ifndef linetracker_h
#define linetracker_h

#include <PhysBot.h>

enum DIRECTIONS {
  GO_STRAIGHT,
  DRIFT_LEFT,
  GO_LEFT,
  DRIFT_RIGHT,
  GO_RIGHT,
  OFF_TRACK
};

//#define DEBUG_EVAL

/** PhysBotSensor is the reflectance sensor.  There are 3 of these on the standard issue
 * robot and are rarely used alone.  An instance is generated for each sensor and encapsulated
 * in a larger object: PhysBotLineFollower.  
 **/
class PhysBotSensor {
  public:
    PhysBotSensor(int pin);  // Configure a pin as a sensor.
    int read();              // Return the current value of the pin.
    inline void setBGLevel( int bgLevel )   	{_BGLevel = bgLevel;}
    inline int getBGLevel( ) 	  				{return _BGLevel;}
    inline void setDetectLevel( int detLevel )	{_detectLevel = detLevel;}
    inline int getDetectLevel( )				{return _detectLevel;}
    boolean isOnline();      // true if we are over a line.

  private:
    boolean calStatus();    // Have both calibrated levels been set yet?
    int _pin;
    int _BGLevel;
    int _detectLevel;
};

/***
 * A class for observing the line following LED/photocells
 * RedBotSensor is supposed to to track many of the threshhold values
 * we track here but a) we need to coordinate the values from the three
 * and 2) we need to set threshhold and bakground values in coordination.
 */
class PhysBotLineTracker {

  public:
    PhysBotLineTracker( PhysBotMotors* motorPtr );

    // Calibrate the three sensors upon this call de.
    void  autoCalibrate();

    // Set threshholds   (for manual override)
    void setBGLevels( int rght, int cent, int left );
    void setBGLevels( int val );
    void setDetectLevels( int rght, int cent, int left );
    void setDetectLevels( int val );
    void setContrast();  // called after setting the BG and Detection levels to determine the contrast

    // Called periodically to update the values from the sensors
    void update();

    // Return the conclusion from the sensors.  You can use this to develop your own routines.
    DIRECTIONS check();

    // actually try to follow the line.  This needs to be called in the loop() function.
    void followLine();

  private:

    PhysBotSensor* _IRSLeft;
    PhysBotSensor* _IRSCent;
    PhysBotSensor* _IRSRght;

    int _rghtDT;
    int _centDT;
    int _leftDT;

    int _rghtRA;
    int _centRA;
    int _leftRA;

    PhysBotMotors* motors;

    boolean _darkLineOnLightSurface;
    DIRECTIONS lastDecision;
    unsigned long lastCheckTime;

};

#endif
