/****************************************************************
Implementation of PhysBotSensor a class to manage the values of a 
single IR linefollowing sensor.

Original Message:
This code is beerware; if you use it, please buy me (or any other
SparkFun employee) a cold beverage next time you run into one of
us at the local.

21 Jan 2014- Mike Hord, SparkFun Electronics

Code developed in Arduino 1.0.5, on an SparkFun Redbot v12.

17 Aug 2015- P. Beeken, Byram Hills High School

17 Aug 2015- P. Beeken, Byram Hils High School

Tested and developed in Arduino 1.6.5 on a SparkFun RedBot ROB-13166
all of our machines also come with wheel encoders.  They are not 
supplied with whiskers or xBees. We are too cheap.
****************************************************************/
#include <Arduino.h>
#include <PhysBotLineTracker.h>

/**
 *  Initialize the pin
 */
PhysBotSensor::PhysBotSensor( int pin )
{
	_pin = pin;
	_BGLevel = -1;
	_detectLevel = -1;
	pinMode(_pin, INPUT);
}

/**
 *  
 */
int
PhysBotSensor::read()
{
  return analogRead(_pin);
}

