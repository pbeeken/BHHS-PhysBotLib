/****************************************************************
Implementation for PhysBotLineTracker

This class develops a full control servo for line following.  With
only three sensors it is tricky to get a good control system operational.
The secret, it turns out is to set the spacing of the sensors so they 
match the line width.  We 3D printed different holders to get the spacing to
match a 1" masking tape line.  The result are 5 control points and an 
ALLSTOP control point.

17 Aug 2015- P. Beeken, Byram Hils High School

Tested and developed in Arduino 1.6.5 on a SparkFun RedBot ROB-13166
all of our machines also come with wheel encoders.  They are not 
supplied with whiskers or xBees. We are too cheap.
****************************************************************/
#include <Arduino.h>
#include <PhysBotLineTracker.h>


// This allows a set of debugging messages to run
#ifdef DEBUG_EVAL
#define REPORT( val ) Serial << val
#else
#define REPORT( val )
#endif


/***
 * Implementation of the routines for following lines.
 * As line gets darker the value returned from sensor gets larger.
 *
 * New condition. What if we are on a dark background and the line is light?
 * Our tables are dark and the tape might be light colored.  Turns out the map
 * function takes care of it all.  It will invert the values to match our test
 * points.  See the check() routine.
 */

/***
 * Instantiate and initialize the object
 */
PhysBotLineTracker::PhysBotLineTracker( PhysBotMotors* motorPtr ) {

  motors = motorPtr;

  _IRSLeft = new PhysBotSensor( A3 ); // initialize a sensor object on A3
  _IRSCent = new PhysBotSensor( A6 ); // initialize a sensor object on A6
  _IRSRght = new PhysBotSensor( A7 ); // initialize a sensor object on A7

}

/***
 * Autocalibrate
 * Place the robot so that the center sensor is on the line and the others are hanging off
 * this will set the levels automatically.
 */
void
PhysBotLineTracker::autoCalibrate() {

  // prepare the analog devices for reading
  _IRSRght->read();  // throw away first value
  _rghtRA = 0;
  for ( int i = 0; i < 10; i++ ) {
    delay( 15 );
    _rghtRA += _IRSRght->read();
    // why the delay, because there is a settling time associated with the arduino
    // http://meettechniek.info/embedded/arduino-analog.html
  }

  _IRSCent->read();  // throw away first value
  _centRA = 0;
  for ( int i = 0; i < 10; i++ ) {
    delay( 15 );
    _centRA += _IRSCent->read();
    // why the delay, because there is a settling time associated with the arduino
    // http://meettechniek.info/embedded/arduino-analog.html
  }

  _IRSLeft->read();  // throw away first value
  _leftRA = 0;
  for ( int i = 0; i < 10; i++ ) {
    delay( 15 );
    _leftRA += _IRSLeft->read();
    // why the delay, because there is a settling time associated with the arduino
    // http://meettechniek.info/embedded/arduino-analog.html
  }

  // Store averages
  setBGLevels( (_rghtRA + _leftRA) / 20 );
  setDetectLevels( _centRA / 10 );

  // if BG < Detect we are dealing with a dark line on light background.
  //    Otherwise we are dealing with light on dark background.
  _darkLineOnLightSurface = _IRSCent->getBGLevel() < _IRSCent->getDetectLevel();

  // Tweak to allow variation
  if ( _darkLineOnLightSurface ) {
    setBGLevels( _IRSLeft->getBGLevel() * 10 / 8 );  // Shift up by 20% to allow for darker regions
    setDetectLevels( _IRSCent->getDetectLevel() * 8 / 10 );  // Shift down by 80% to allow for more reflectivity
  } else {
    setBGLevels( _IRSLeft->getBGLevel() * 8 / 10 );  // Shift up by 20% to allow for darker regions
    setDetectLevels( _IRSCent->getDetectLevel() * 10 / 8 );  // Shift down by 80% to allow for more reflectivity
  }

  lastCheckTime = millis();

  REPORT(  " Level Set... " << endl );
  REPORT( "dt: " << _IRSCent->getDetectLevel() << " bg: " << _IRSCent->getBGLevel() << endl );
  if ( _darkLineOnLightSurface )
    REPORT( "Dark line, light surface" << endl );
  else
    REPORT( "Light line, dark surface" << endl );

}

/***
 * setBGLevels sets the normal reflectivity
 * @param {int, int, int} right, center, left values which represents a clear surface
 */
void PhysBotLineTracker::setBGLevels( int rght, int cent, int left ) {
  _IRSLeft->setBGLevel( rght );
  _IRSCent->setBGLevel( cent );
  _IRSRght->setBGLevel( left );
}

/***
 * setBGLevels sets the normal reflectivity
 * @param {int} allvalues values which represents a clear surface
 */
void PhysBotLineTracker::setBGLevels( int val ) {
  setBGLevels( val, val, val );
}

/***
 * setDetectLevels sets the threshhold above which we  say we are over a line
 * @param {int, int, int} right, center, left values which represents a detected line
 */
void PhysBotLineTracker::setDetectLevels( int rght, int cent, int left ) {
  _IRSLeft->setDetectLevel( rght );
  _IRSCent->setDetectLevel( cent );
  _IRSRght->setDetectLevel( left );
}

/***
 * setDetectLevels sets the threshhold above which we  say we are over a line
 * @param {int} values which represents a detected line
 */
void PhysBotLineTracker::setDetectLevels( int val ) {
  setDetectLevels( val, val, val );
}

/***
 * update is to be called periodically (like every time through a loop) to update the status of the detect
 * NB this may not be the best way to report on the line, we may need to "flag" instead of average.
 */
void PhysBotLineTracker::update() {

  if ( millis() < lastCheckTime + 5 ) return;  // exit if less than preset time.

  // We gather the values but average them in with the previous values
  _rghtRA += _IRSRght->read();
  _centRA += _IRSCent->read();
  _leftRA += _IRSLeft->read();
  _rghtRA /= 2;
  _centRA /= 2;
  _leftRA /= 2;

  lastCheckTime = millis();
}


#define MAX  100
#define MIN  0

/***
 * Report on threshhold reading. Although we are reading from Analog values note that
 * the values on the sensors are essentially digital. Once off the line they read bacground
 * otherwise they read full reflectance. With some experiments with graded tape we may get finer control.
 * But until then we have to deal with on or off.  Another issue is transitioning. As the robot goes off course
 * we need to consider that we may get an anomoulous result. N.B. This routine does nothing with the data other
 * than condition it for further processing.
 */
DIRECTIONS PhysBotLineTracker::check() {

  int onLine = MIN;
  int offLine = MAX;

  int rghtSig = map( _rghtRA, _IRSRght->getBGLevel(), _IRSRght->getDetectLevel(), MIN, MAX );
    rghtSig = constrain( rghtSig, MIN, MAX );
  int centSig = map( _centRA, _IRSCent->getBGLevel(), _IRSCent->getDetectLevel(), MIN, MAX );
    centSig = constrain( centSig, MIN, MAX );
  int leftSig = map( _leftRA, _IRSLeft->getBGLevel(), _IRSLeft->getDetectLevel(), MIN, MAX );
    leftSig = constrain( leftSig, MIN, MAX );

  REPORT( "L: " << leftSig << "\tC: " << centSig << "\tR: " << rghtSig << "\t" );

  if ( leftSig <= 50 && centSig > 50 && rghtSig <= 50) { // on line more or less
    lastDecision = GO_STRAIGHT;
    return GO_STRAIGHT;  // Go Straight
  }

  // depending on the line width we may not see this
  if ( leftSig > 50 && centSig > 50 && rghtSig <= 50 ) {
    lastDecision = DRIFT_RIGHT;
    return DRIFT_RIGHT; // right sensor is over line, ease right
  }

  // depending on the line width we may not see this
  if ( leftSig <= 50 && centSig > 50 && rghtSig > 50 ) {
    lastDecision = DRIFT_LEFT;
    return DRIFT_LEFT; // left sensor is over line, ease left
  }

  if ( leftSig <= 50 && centSig <= 50 && rghtSig > 50 ) {
    lastDecision = GO_LEFT;
    return GO_LEFT; // right sensor is over line, turn hard left
  }

  if ( leftSig > 50 && centSig <= 50 && rghtSig <= 50 ) {
    lastDecision = GO_RIGHT;
    return GO_RIGHT; // left sensor is over line, turn hard right
  }

  // i don't know where I am.
  lastDecision = OFF_TRACK;
  return OFF_TRACK; // don't know what to do. Stop?

}

#define PERC_ADJ  80

void
PhysBotLineTracker::followLine() {

  update(); // update the sensors.

  // act on the data...
  switch ( check() ) {
    case GO_STRAIGHT:
      REPORT( "- S-" );
      motors->adjustSpeed( 0, BOTH );
      break;

    case GO_RIGHT:
      REPORT( "- R-" );
      motors->adjustSpeed( -PERC_ADJ, LEFT );
      motors->adjustSpeed( PERC_ADJ, RIGHT );
      break;

    case GO_LEFT:
      REPORT( "- L-" );
      motors->adjustSpeed( PERC_ADJ, LEFT );
      motors->adjustSpeed( -PERC_ADJ, RIGHT );
      break;

    case DRIFT_RIGHT:  // May not see this condition
      REPORT( "-DR-" );
      motors->adjustSpeed( PERC_ADJ, RIGHT );
      motors->adjustSpeed( 0, LEFT );
      break;

    case DRIFT_LEFT:  // May not see this condition
      REPORT( "-DL-" );
      motors->adjustSpeed( 0, RIGHT );
      motors->adjustSpeed( PERC_ADJ, LEFT );
      break;

    case OFF_TRACK:
      motors->adjustSpeed( 0, BOTH ); // Reset
      motors->brake();
      delay( 50 );
      REPORT( "- O-" );
      break;
  }

  REPORT( endl );

}
