/****************************************************************
Core header file for all the various PhysBot functions.

- From the original RedBot.h file:
There is additional license info below regarding the use of the
SoftwareSerial library from Arduino 1.0.5; I had good and sound
reasons for creating a derivative class rather than asking users
to simply use the existing library, which are documented below.

This code is beerware; if you use it, please buy me (or any other
SparkFun employee) a cold beverage next time you run into one of
us at the local.

21 Jan 2014- Mike Hord, SparkFun Electronics
Code developed in Arduino 1.0.5, on an SparkFun Redbot v12.

Extensive modification. Some classes were left as is, many more 
added. Most were adjusted and rewritten in one form or another.
Many of the lowest level access routines and interrupt service 
handlers were left pretty much, as is.  Higher level routines were
modified to match our specific needs and hardware.  Most importantly:
routines that previously BLOCKED are now gone.  BLOCKING means that for
a given method, when called, would hold the full attention of the Arduino
until it finished its task, thus blocking other routines from doing their
job.  In all classes which need to perform periodic tasks look for a
method called 'update'.  This is the method that needs to be called once
per 'loop()' to check to see if something needs to be done.  If not, that
object's update method returns quickly so other object update routines can
get on with their jobs as well.  Ideally we could register these things in a
scheduler class but that is for another day.
17 Aug 2015- P. Beeken, Byram Hils High School

Tested and developed in Arduino 1.6.5 on a SparkFun RedBot ROB-13166
all of our machines also come with wheel encoders.  They are not 
supplied with whiskers or xBees. We are too cheap.
****************************************************************/

#ifndef PhysBot_h
#define PhysBot_h

/** PCINT functionality aliases. Each PCINT has a value set up when the
 *  class member gets created, and the PCINT service routine will handle
 *  the choosing the appropriate response to the interrupt.
 */

#define NOT_IN_USE    0
#define WHISKER       1
#define LENCODER      2
#define RENCODER      3
#define SW_SERIAL     4

#define PCINT_A0      0
#define PCINT_A1      1
#define PCINT_A2      2
#define PCINT_A3      3
#define PCINT_A4      4
#define PCINT_A5      5
#define PCINT_3       6
#define PCINT_9       7
#define PCINT_10      8
#define PCINT_11      9

enum WHEEL {LEFT, RIGHT, BOTH};	// Variable for which wheel you're interested in
								//  when you do things in the motor or encoder class.

/** These three functions need to work from within multiple classes, so we keep
 *  them separate and add them as friend functions where appropriate.
 */
void setPinChangeInterrupt(int pin, byte role); // The "role" of each pin is
                  //  stored in an array which is accessed in the interrupt
                  //  handler to determine what should be done on a falling edge
                  //  PC interrupt.
void pinFunctionHandler(byte pinIndex); // This is the function which actually
                  //  handles the legwork after the interrupt has identified
                  //  which pin caught the interrupt.
//void brake(void); // Globally accessible motor brake. I couldn't figure out how
                  //  to set a function pointer to the PhysBotMotors class
                  //  function, and it's a small function, so I just made a
                  //  global in the library.  
                  // Use a static method. PBB, will test when we get around to using whiskers
void PC0Handler(byte PBTemp);
void PC1Handler(byte PCTemp);
void PC2Handler(byte PDTemp);

#define RESET	1024 // Special flag for anything with a speed, real speed values cannot be this high so this works as a message.

/** This class handles motor functionality. I expect only one instance of this
 *  in a thread.  We can manipulate both or each wheel independently given the parameters
 **/
class PhysBotMotors
{
  public:
    PhysBotMotors();          // Constructor. Mainly sets up pins.
    
    // Non blocking routines
    void drive( int speed, WHEEL wheel=BOTH );	// Drive in direction given by sign, at speed given by magnitude of the parameter.
    void pivot( int speed );  					// Pivot more or less in place. Turns motors in opposite directions

	// These are the stopping/halting routines
	void coast( WHEEL wheel=BOTH );				// Stop motors, but allow them to coast to a halt.
	static void brake( WHEEL wheel=BOTH );		// Quick-stop the motors, shorting the leads.  static so we can access outside

	// getters and setters
    int getSpeed( WHEEL wheel=BOTH );         // As we move to async routines we need to recall this value.
    void adjustSpeed( int percentage, WHEEL wheel=BOTH );	// the percentage to adjust the wheel speed.  (-100<->100)
    		// This is useful for tuning direction without overriding the speed entirely.  For example we can use
    		// these parameters to adjust for a slight drift or we can use this to turn the 'bot with a line 
    		// following servo to turn the cart without changing the assigned speed.
    void turn( int percentage );  // we can use this to perform an adjusted turn of the amount given. -100<perc<100
            //  is the degree to drift left or right.

  private:
	void rightCoast();				// Stop right motor, as with coast().
	void leftCoast();				// Stop left motor, as with coast().
	static void leftBrake();		// Quick-stop left motor, as with brake().	static so we can access outside
	static void rightBrake();		// Quick-stop right motor, as with brake().	static so we can access outside

    void leftFwd(byte speed);		// These functions are pretty self-explanatory,
    void leftRev(byte speed);		//  and are called by the above functions once
    void rightFwd(byte speed);		//  sign has been used to determine direction.
    void rightRev(byte speed);

	int _leftSpeed;					// memory of the last speed setting
	int _rightSpeed;
	
	int _leftTweak;					// tweaks applied to speed to vary the wheels
	int _rightTweak;
};

/** Encoder handler.  Like the motor handler above we are allowed only one instantiation
 * per running program.  It encapsulates all the methods and variables we need to manage
 * the information from the encoders.  It works closely with the motor instance to correctly
 * count the wheel movement.  If I were clever, I would actually subclass motor and make
 * a virtual method here that would override the ISR so we would track the movement.  Then
 * the PhysBotKinematics class which converts these actions into measurements would make more
 * sense.
 * From original file [RedBot.h]:
 * When a negative going edge happens on an encoder pin, a counter is
 * incremented (or decremented), depending on the direction last determined
 * by one of the motor direction commands.
 **/
class PhysBotEncoder
{
  // We declare a couple of friends, so they can have access to the private
  //  members of this class.
  friend class PhysBotMotors;  // Needs access to lDir and rDir.
  friend void pinFunctionHandler(byte pinIndex); // Called from within the
                             //  ISRs, this function increments the counts
                             //  by calling wheelTick().
  public:
    PhysBotEncoder(int lPin, int rPin); // Constructor. Assigns pins, pin
                             //  functions, zeroes counters, and adds a
                             //  reference to the new encoder object for other
                             //  library members to access.
    void clear(WHEEL wheel=BOTH); // Zaps the encoder count for a given wheel (or
                             //  for both wheels).
    long getTicks(WHEEL wheel=BOTH); // Returns the encoder count for a wheel.
    unsigned long getPeriod(WHEEL wheel=BOTH); // Returns microseconds for a single encoder rotation
    unsigned long getTime(WHEEL wheel=BOTH); // Returns microseconds since last reset

  private:
  	static PhysBotEncoder* encoderObj;	// a pointer to the instance of this object for friends
										// this shouldn't be necessary if I were to declare wheelTick,
										// _lDir and _rDir as static.
  	
    void wheelTick(WHEEL wheel);	// Increment or decrement a wheel's counts,
									//  depending on which way the motor is turning.
    long _lCounts, _rCounts;		// Holds the number of ticks for that wheel's encoder.
    char _lDir, _rDir;				// Direction is set by the motor class, according
									//  to what the most recent motion direction for
									//  the given wheel was.
    unsigned long _lTime, _rTime;	// The total time markers for the ticks
    unsigned long _slTime, _srTime;	// start time index for total time
    unsigned long _rPer, _lPer;		// The time in microseconds between revolution.
    unsigned long _sLp, _sRp;		// start markers for period.
};

/** PhysBotButton contains the methods we need to read the one input we have on the
 * firmware board. The class can handle a single or multiple debounced pushes.
 **/
class PhysBotButton
{
  public:
    PhysBotButton();			// Constructor. Mainly sets up pins.
    boolean readSinglePush();	// read a single button push (as a button up)
    boolean readDoublePush();	// read a double tap.
    int	readPushes();			// count multiple pushes
    boolean buttonIsDown();		// raw read from button
};

/** PhysBotBlinker is a convenience class to encapsulate the one easy visual 
 * feedback we have: pin 13, the built-in LED
 **/
class PhysBotBlinker
{
	public:
		PhysBotBlinker( int pin=13 );	// Constructor with led connected to pin.
		
		void update();				// placed in loop() to periodically update actions
		void setBlinkPeriod( unsigned long period=500 );	// set the blinking period
		void blinkFor( int nTimes );	// blink the led for a finite number (blocks)
		void activate() { _active = true; }		// turn on asynchronous routines
		void deactivate() { _active = false; }	// turn off asynchronous routines

	private:
		boolean _active;
		unsigned long _change;
		unsigned long _blinkPeriod;
		boolean _ledIsOn;
		int _ledPin;
};


#endif